export type Role = {
    id: number;
    slug: string;
    name: string;
    description?: string | null;
};

export type User = {
    id: number;
    name: string;
    email: string;
    username?: string | null;
    phone?: string | null;
    role: string;
    role_id?: number | null;
    role_relation?: Role | null;
    status?: 'active' | 'inactive' | 'suspended';
    profile_image?: string | null;
    last_login_at?: string | null;
    avatar?: string;
    email_verified_at: string | null;
    two_factor_enabled?: boolean;
    created_at: string;
    updated_at: string;
    [key: string]: unknown;
};

export type Auth = {
    user: User;
};

export type Passkey = {
    id: number;
    name: string;
    authenticator: string | null;
    created_at_diff: string;
    last_used_at_diff: string | null;
};

export type TwoFactorSetupData = {
    svg: string;
    url: string;
};

export type TwoFactorSecretKey = {
    secretKey: string;
};
