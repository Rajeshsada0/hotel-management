import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\InventoryController::index
 * @see app/Http/Controllers/InventoryController.php:25
 * @route '/inventory'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/inventory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InventoryController::index
 * @see app/Http/Controllers/InventoryController.php:25
 * @route '/inventory'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryController::index
 * @see app/Http/Controllers/InventoryController.php:25
 * @route '/inventory'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InventoryController::index
 * @see app/Http/Controllers/InventoryController.php:25
 * @route '/inventory'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InventoryController::index
 * @see app/Http/Controllers/InventoryController.php:25
 * @route '/inventory'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InventoryController::index
 * @see app/Http/Controllers/InventoryController.php:25
 * @route '/inventory'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InventoryController::index
 * @see app/Http/Controllers/InventoryController.php:25
 * @route '/inventory'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\InventoryController::storeItem
 * @see app/Http/Controllers/InventoryController.php:65
 * @route '/inventory/items'
 */
export const storeItem = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeItem.url(options),
    method: 'post',
})

storeItem.definition = {
    methods: ["post"],
    url: '/inventory/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryController::storeItem
 * @see app/Http/Controllers/InventoryController.php:65
 * @route '/inventory/items'
 */
storeItem.url = (options?: RouteQueryOptions) => {
    return storeItem.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryController::storeItem
 * @see app/Http/Controllers/InventoryController.php:65
 * @route '/inventory/items'
 */
storeItem.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeItem.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryController::storeItem
 * @see app/Http/Controllers/InventoryController.php:65
 * @route '/inventory/items'
 */
    const storeItemForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeItem.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryController::storeItem
 * @see app/Http/Controllers/InventoryController.php:65
 * @route '/inventory/items'
 */
        storeItemForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeItem.url(options),
            method: 'post',
        })
    
    storeItem.form = storeItemForm
/**
* @see \App\Http\Controllers\InventoryController::storeTransaction
 * @see app/Http/Controllers/InventoryController.php:108
 * @route '/inventory/transactions'
 */
export const storeTransaction = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTransaction.url(options),
    method: 'post',
})

storeTransaction.definition = {
    methods: ["post"],
    url: '/inventory/transactions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryController::storeTransaction
 * @see app/Http/Controllers/InventoryController.php:108
 * @route '/inventory/transactions'
 */
storeTransaction.url = (options?: RouteQueryOptions) => {
    return storeTransaction.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryController::storeTransaction
 * @see app/Http/Controllers/InventoryController.php:108
 * @route '/inventory/transactions'
 */
storeTransaction.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTransaction.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryController::storeTransaction
 * @see app/Http/Controllers/InventoryController.php:108
 * @route '/inventory/transactions'
 */
    const storeTransactionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeTransaction.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryController::storeTransaction
 * @see app/Http/Controllers/InventoryController.php:108
 * @route '/inventory/transactions'
 */
        storeTransactionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeTransaction.url(options),
            method: 'post',
        })
    
    storeTransaction.form = storeTransactionForm
/**
* @see \App\Http\Controllers\InventoryController::storeSupplier
 * @see app/Http/Controllers/InventoryController.php:131
 * @route '/inventory/suppliers'
 */
export const storeSupplier = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSupplier.url(options),
    method: 'post',
})

storeSupplier.definition = {
    methods: ["post"],
    url: '/inventory/suppliers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryController::storeSupplier
 * @see app/Http/Controllers/InventoryController.php:131
 * @route '/inventory/suppliers'
 */
storeSupplier.url = (options?: RouteQueryOptions) => {
    return storeSupplier.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryController::storeSupplier
 * @see app/Http/Controllers/InventoryController.php:131
 * @route '/inventory/suppliers'
 */
storeSupplier.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSupplier.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryController::storeSupplier
 * @see app/Http/Controllers/InventoryController.php:131
 * @route '/inventory/suppliers'
 */
    const storeSupplierForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSupplier.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryController::storeSupplier
 * @see app/Http/Controllers/InventoryController.php:131
 * @route '/inventory/suppliers'
 */
        storeSupplierForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSupplier.url(options),
            method: 'post',
        })
    
    storeSupplier.form = storeSupplierForm
/**
* @see \App\Http\Controllers\InventoryController::storePurchase
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
export const storePurchase = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePurchase.url(options),
    method: 'post',
})

storePurchase.definition = {
    methods: ["post"],
    url: '/inventory/purchases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryController::storePurchase
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
storePurchase.url = (options?: RouteQueryOptions) => {
    return storePurchase.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryController::storePurchase
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
storePurchase.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePurchase.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryController::storePurchase
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
    const storePurchaseForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storePurchase.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryController::storePurchase
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
        storePurchaseForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storePurchase.url(options),
            method: 'post',
        })
    
    storePurchase.form = storePurchaseForm
/**
* @see \App\Http\Controllers\InventoryController::receivePurchase
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
export const receivePurchase = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: receivePurchase.url(args, options),
    method: 'post',
})

receivePurchase.definition = {
    methods: ["post"],
    url: '/inventory/purchases/{purchase}/receive',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryController::receivePurchase
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
receivePurchase.url = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchase: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchase: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchase: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchase: typeof args.purchase === 'object'
                ? args.purchase.id
                : args.purchase,
                }

    return receivePurchase.definition.url
            .replace('{purchase}', parsedArgs.purchase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryController::receivePurchase
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
receivePurchase.post = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: receivePurchase.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryController::receivePurchase
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
    const receivePurchaseForm = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: receivePurchase.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryController::receivePurchase
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
        receivePurchaseForm.post = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: receivePurchase.url(args, options),
            method: 'post',
        })
    
    receivePurchase.form = receivePurchaseForm
const InventoryController = { index, storeItem, storeTransaction, storeSupplier, storePurchase, receivePurchase }

export default InventoryController