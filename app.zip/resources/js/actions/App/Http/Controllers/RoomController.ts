import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RoomController::index
 * @see app/Http/Controllers/RoomController.php:19
 * @route '/rooms'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/rooms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RoomController::index
 * @see app/Http/Controllers/RoomController.php:19
 * @route '/rooms'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RoomController::index
 * @see app/Http/Controllers/RoomController.php:19
 * @route '/rooms'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RoomController::index
 * @see app/Http/Controllers/RoomController.php:19
 * @route '/rooms'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RoomController::index
 * @see app/Http/Controllers/RoomController.php:19
 * @route '/rooms'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RoomController::index
 * @see app/Http/Controllers/RoomController.php:19
 * @route '/rooms'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RoomController::index
 * @see app/Http/Controllers/RoomController.php:19
 * @route '/rooms'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:53
 * @route '/rooms'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/rooms',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:53
 * @route '/rooms'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:53
 * @route '/rooms'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:53
 * @route '/rooms'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:53
 * @route '/rooms'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:76
 * @route '/rooms/{room}'
 */
export const update = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/rooms/{room}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:76
 * @route '/rooms/{room}'
 */
update.url = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { room: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { room: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    room: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        room: typeof args.room === 'object'
                ? args.room.id
                : args.room,
                }

    return update.definition.url
            .replace('{room}', parsedArgs.room.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:76
 * @route '/rooms/{room}'
 */
update.put = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:76
 * @route '/rooms/{room}'
 */
    const updateForm = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:76
 * @route '/rooms/{room}'
 */
        updateForm.put = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\RoomController::updateStatus
 * @see app/Http/Controllers/RoomController.php:98
 * @route '/rooms/{room}/status'
 */
export const updateStatus = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/rooms/{room}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\RoomController::updateStatus
 * @see app/Http/Controllers/RoomController.php:98
 * @route '/rooms/{room}/status'
 */
updateStatus.url = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { room: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { room: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    room: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        room: typeof args.room === 'object'
                ? args.room.id
                : args.room,
                }

    return updateStatus.definition.url
            .replace('{room}', parsedArgs.room.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RoomController::updateStatus
 * @see app/Http/Controllers/RoomController.php:98
 * @route '/rooms/{room}/status'
 */
updateStatus.patch = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\RoomController::updateStatus
 * @see app/Http/Controllers/RoomController.php:98
 * @route '/rooms/{room}/status'
 */
    const updateStatusForm = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RoomController::updateStatus
 * @see app/Http/Controllers/RoomController.php:98
 * @route '/rooms/{room}/status'
 */
        updateStatusForm.patch = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\RoomController::storeType
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
export const storeType = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeType.url(options),
    method: 'post',
})

storeType.definition = {
    methods: ["post"],
    url: '/room-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RoomController::storeType
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
storeType.url = (options?: RouteQueryOptions) => {
    return storeType.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RoomController::storeType
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
storeType.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeType.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RoomController::storeType
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
    const storeTypeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeType.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RoomController::storeType
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
        storeTypeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeType.url(options),
            method: 'post',
        })
    
    storeType.form = storeTypeForm
/**
* @see \App\Http\Controllers\RoomController::updateType
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
export const updateType = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateType.url(args, options),
    method: 'put',
})

updateType.definition = {
    methods: ["put"],
    url: '/room-types/{roomType}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\RoomController::updateType
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
updateType.url = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { roomType: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { roomType: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    roomType: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        roomType: typeof args.roomType === 'object'
                ? args.roomType.id
                : args.roomType,
                }

    return updateType.definition.url
            .replace('{roomType}', parsedArgs.roomType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RoomController::updateType
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
updateType.put = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateType.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\RoomController::updateType
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
    const updateTypeForm = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateType.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RoomController::updateType
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
        updateTypeForm.put = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateType.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateType.form = updateTypeForm
const RoomController = { index, store, update, updateStatus, storeType, updateType }

export default RoomController