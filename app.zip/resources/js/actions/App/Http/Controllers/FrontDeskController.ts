import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FrontDeskController::index
 * @see app/Http/Controllers/FrontDeskController.php:26
 * @route '/front-desk'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/front-desk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FrontDeskController::index
 * @see app/Http/Controllers/FrontDeskController.php:26
 * @route '/front-desk'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FrontDeskController::index
 * @see app/Http/Controllers/FrontDeskController.php:26
 * @route '/front-desk'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FrontDeskController::index
 * @see app/Http/Controllers/FrontDeskController.php:26
 * @route '/front-desk'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FrontDeskController::index
 * @see app/Http/Controllers/FrontDeskController.php:26
 * @route '/front-desk'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FrontDeskController::index
 * @see app/Http/Controllers/FrontDeskController.php:26
 * @route '/front-desk'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FrontDeskController::index
 * @see app/Http/Controllers/FrontDeskController.php:26
 * @route '/front-desk'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\FrontDeskController::availability
 * @see app/Http/Controllers/FrontDeskController.php:71
 * @route '/availability'
 */
export const availability = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})

availability.definition = {
    methods: ["get","head"],
    url: '/availability',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FrontDeskController::availability
 * @see app/Http/Controllers/FrontDeskController.php:71
 * @route '/availability'
 */
availability.url = (options?: RouteQueryOptions) => {
    return availability.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FrontDeskController::availability
 * @see app/Http/Controllers/FrontDeskController.php:71
 * @route '/availability'
 */
availability.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FrontDeskController::availability
 * @see app/Http/Controllers/FrontDeskController.php:71
 * @route '/availability'
 */
availability.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availability.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FrontDeskController::availability
 * @see app/Http/Controllers/FrontDeskController.php:71
 * @route '/availability'
 */
    const availabilityForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: availability.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FrontDeskController::availability
 * @see app/Http/Controllers/FrontDeskController.php:71
 * @route '/availability'
 */
        availabilityForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FrontDeskController::availability
 * @see app/Http/Controllers/FrontDeskController.php:71
 * @route '/availability'
 */
        availabilityForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    availability.form = availabilityForm
/**
* @see \App\Http\Controllers\FrontDeskController::checkIn
 * @see app/Http/Controllers/FrontDeskController.php:108
 * @route '/front-desk/check-in/{reservation}'
 */
export const checkIn = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkIn.url(args, options),
    method: 'post',
})

checkIn.definition = {
    methods: ["post"],
    url: '/front-desk/check-in/{reservation}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FrontDeskController::checkIn
 * @see app/Http/Controllers/FrontDeskController.php:108
 * @route '/front-desk/check-in/{reservation}'
 */
checkIn.url = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reservation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { reservation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    reservation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reservation: typeof args.reservation === 'object'
                ? args.reservation.id
                : args.reservation,
                }

    return checkIn.definition.url
            .replace('{reservation}', parsedArgs.reservation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FrontDeskController::checkIn
 * @see app/Http/Controllers/FrontDeskController.php:108
 * @route '/front-desk/check-in/{reservation}'
 */
checkIn.post = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkIn.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FrontDeskController::checkIn
 * @see app/Http/Controllers/FrontDeskController.php:108
 * @route '/front-desk/check-in/{reservation}'
 */
    const checkInForm = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkIn.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FrontDeskController::checkIn
 * @see app/Http/Controllers/FrontDeskController.php:108
 * @route '/front-desk/check-in/{reservation}'
 */
        checkInForm.post = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkIn.url(args, options),
            method: 'post',
        })
    
    checkIn.form = checkInForm
/**
* @see \App\Http\Controllers\FrontDeskController::checkOut
 * @see app/Http/Controllers/FrontDeskController.php:126
 * @route '/front-desk/check-out/{reservation}'
 */
export const checkOut = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkOut.url(args, options),
    method: 'post',
})

checkOut.definition = {
    methods: ["post"],
    url: '/front-desk/check-out/{reservation}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FrontDeskController::checkOut
 * @see app/Http/Controllers/FrontDeskController.php:126
 * @route '/front-desk/check-out/{reservation}'
 */
checkOut.url = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reservation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { reservation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    reservation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reservation: typeof args.reservation === 'object'
                ? args.reservation.id
                : args.reservation,
                }

    return checkOut.definition.url
            .replace('{reservation}', parsedArgs.reservation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FrontDeskController::checkOut
 * @see app/Http/Controllers/FrontDeskController.php:126
 * @route '/front-desk/check-out/{reservation}'
 */
checkOut.post = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkOut.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FrontDeskController::checkOut
 * @see app/Http/Controllers/FrontDeskController.php:126
 * @route '/front-desk/check-out/{reservation}'
 */
    const checkOutForm = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkOut.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FrontDeskController::checkOut
 * @see app/Http/Controllers/FrontDeskController.php:126
 * @route '/front-desk/check-out/{reservation}'
 */
        checkOutForm.post = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkOut.url(args, options),
            method: 'post',
        })
    
    checkOut.form = checkOutForm
/**
* @see \App\Http\Controllers\FrontDeskController::walkIn
 * @see app/Http/Controllers/FrontDeskController.php:142
 * @route '/front-desk/walk-in'
 */
export const walkIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: walkIn.url(options),
    method: 'post',
})

walkIn.definition = {
    methods: ["post"],
    url: '/front-desk/walk-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FrontDeskController::walkIn
 * @see app/Http/Controllers/FrontDeskController.php:142
 * @route '/front-desk/walk-in'
 */
walkIn.url = (options?: RouteQueryOptions) => {
    return walkIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FrontDeskController::walkIn
 * @see app/Http/Controllers/FrontDeskController.php:142
 * @route '/front-desk/walk-in'
 */
walkIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: walkIn.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FrontDeskController::walkIn
 * @see app/Http/Controllers/FrontDeskController.php:142
 * @route '/front-desk/walk-in'
 */
    const walkInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: walkIn.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FrontDeskController::walkIn
 * @see app/Http/Controllers/FrontDeskController.php:142
 * @route '/front-desk/walk-in'
 */
        walkInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: walkIn.url(options),
            method: 'post',
        })
    
    walkIn.form = walkInForm
const FrontDeskController = { index, availability, checkIn, checkOut, walkIn }

export default FrontDeskController