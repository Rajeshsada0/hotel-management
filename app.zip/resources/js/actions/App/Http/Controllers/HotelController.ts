import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\HotelController::edit
 * @see app/Http/Controllers/HotelController.php:16
 * @route '/settings/hotel'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/hotel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HotelController::edit
 * @see app/Http/Controllers/HotelController.php:16
 * @route '/settings/hotel'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HotelController::edit
 * @see app/Http/Controllers/HotelController.php:16
 * @route '/settings/hotel'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HotelController::edit
 * @see app/Http/Controllers/HotelController.php:16
 * @route '/settings/hotel'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HotelController::edit
 * @see app/Http/Controllers/HotelController.php:16
 * @route '/settings/hotel'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HotelController::edit
 * @see app/Http/Controllers/HotelController.php:16
 * @route '/settings/hotel'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HotelController::edit
 * @see app/Http/Controllers/HotelController.php:16
 * @route '/settings/hotel'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\HotelController::update
 * @see app/Http/Controllers/HotelController.php:36
 * @route '/settings/hotel'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/hotel',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\HotelController::update
 * @see app/Http/Controllers/HotelController.php:36
 * @route '/settings/hotel'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HotelController::update
 * @see app/Http/Controllers/HotelController.php:36
 * @route '/settings/hotel'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\HotelController::update
 * @see app/Http/Controllers/HotelController.php:36
 * @route '/settings/hotel'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HotelController::update
 * @see app/Http/Controllers/HotelController.php:36
 * @route '/settings/hotel'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const HotelController = { edit, update }

export default HotelController