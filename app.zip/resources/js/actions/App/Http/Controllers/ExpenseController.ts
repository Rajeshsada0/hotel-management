import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ExpenseController::index
 * @see app/Http/Controllers/ExpenseController.php:23
 * @route '/expenses'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ExpenseController::index
 * @see app/Http/Controllers/ExpenseController.php:23
 * @route '/expenses'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpenseController::index
 * @see app/Http/Controllers/ExpenseController.php:23
 * @route '/expenses'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ExpenseController::index
 * @see app/Http/Controllers/ExpenseController.php:23
 * @route '/expenses'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ExpenseController::index
 * @see app/Http/Controllers/ExpenseController.php:23
 * @route '/expenses'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ExpenseController::index
 * @see app/Http/Controllers/ExpenseController.php:23
 * @route '/expenses'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ExpenseController::index
 * @see app/Http/Controllers/ExpenseController.php:23
 * @route '/expenses'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ExpenseController::store
 * @see app/Http/Controllers/ExpenseController.php:49
 * @route '/expenses'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/expenses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ExpenseController::store
 * @see app/Http/Controllers/ExpenseController.php:49
 * @route '/expenses'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpenseController::store
 * @see app/Http/Controllers/ExpenseController.php:49
 * @route '/expenses'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ExpenseController::store
 * @see app/Http/Controllers/ExpenseController.php:49
 * @route '/expenses'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ExpenseController::store
 * @see app/Http/Controllers/ExpenseController.php:49
 * @route '/expenses'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ExpenseController::storeStaff
 * @see app/Http/Controllers/ExpenseController.php:69
 * @route '/expenses/staff'
 */
export const storeStaff = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStaff.url(options),
    method: 'post',
})

storeStaff.definition = {
    methods: ["post"],
    url: '/expenses/staff',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ExpenseController::storeStaff
 * @see app/Http/Controllers/ExpenseController.php:69
 * @route '/expenses/staff'
 */
storeStaff.url = (options?: RouteQueryOptions) => {
    return storeStaff.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpenseController::storeStaff
 * @see app/Http/Controllers/ExpenseController.php:69
 * @route '/expenses/staff'
 */
storeStaff.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStaff.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ExpenseController::storeStaff
 * @see app/Http/Controllers/ExpenseController.php:69
 * @route '/expenses/staff'
 */
    const storeStaffForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStaff.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ExpenseController::storeStaff
 * @see app/Http/Controllers/ExpenseController.php:69
 * @route '/expenses/staff'
 */
        storeStaffForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStaff.url(options),
            method: 'post',
        })
    
    storeStaff.form = storeStaffForm
const ExpenseController = { index, store, storeStaff }

export default ExpenseController