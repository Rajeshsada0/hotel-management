import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\HotelServiceController::index
 * @see app/Http/Controllers/HotelServiceController.php:24
 * @route '/services'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HotelServiceController::index
 * @see app/Http/Controllers/HotelServiceController.php:24
 * @route '/services'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HotelServiceController::index
 * @see app/Http/Controllers/HotelServiceController.php:24
 * @route '/services'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HotelServiceController::index
 * @see app/Http/Controllers/HotelServiceController.php:24
 * @route '/services'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HotelServiceController::index
 * @see app/Http/Controllers/HotelServiceController.php:24
 * @route '/services'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HotelServiceController::index
 * @see app/Http/Controllers/HotelServiceController.php:24
 * @route '/services'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HotelServiceController::index
 * @see app/Http/Controllers/HotelServiceController.php:24
 * @route '/services'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\HotelServiceController::store
 * @see app/Http/Controllers/HotelServiceController.php:53
 * @route '/services'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/services',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HotelServiceController::store
 * @see app/Http/Controllers/HotelServiceController.php:53
 * @route '/services'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HotelServiceController::store
 * @see app/Http/Controllers/HotelServiceController.php:53
 * @route '/services'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HotelServiceController::store
 * @see app/Http/Controllers/HotelServiceController.php:53
 * @route '/services'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HotelServiceController::store
 * @see app/Http/Controllers/HotelServiceController.php:53
 * @route '/services'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\HotelServiceController::order
 * @see app/Http/Controllers/HotelServiceController.php:74
 * @route '/services/order'
 */
export const order = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: order.url(options),
    method: 'post',
})

order.definition = {
    methods: ["post"],
    url: '/services/order',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HotelServiceController::order
 * @see app/Http/Controllers/HotelServiceController.php:74
 * @route '/services/order'
 */
order.url = (options?: RouteQueryOptions) => {
    return order.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HotelServiceController::order
 * @see app/Http/Controllers/HotelServiceController.php:74
 * @route '/services/order'
 */
order.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: order.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HotelServiceController::order
 * @see app/Http/Controllers/HotelServiceController.php:74
 * @route '/services/order'
 */
    const orderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: order.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HotelServiceController::order
 * @see app/Http/Controllers/HotelServiceController.php:74
 * @route '/services/order'
 */
        orderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: order.url(options),
            method: 'post',
        })
    
    order.form = orderForm
const HotelServiceController = { index, store, order }

export default HotelServiceController