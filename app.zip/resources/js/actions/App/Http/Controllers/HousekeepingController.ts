import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/housekeeping',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
export const assign = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assign.url(options),
    method: 'post',
})

assign.definition = {
    methods: ["post"],
    url: '/housekeeping/assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
assign.url = (options?: RouteQueryOptions) => {
    return assign.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
assign.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assign.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
    const assignForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assign.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
        assignForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assign.url(options),
            method: 'post',
        })
    
    assign.form = assignForm
/**
* @see \App\Http\Controllers\HousekeepingController::updateStatus
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
export const updateStatus = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/housekeeping/tasks/{task}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\HousekeepingController::updateStatus
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
updateStatus.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return updateStatus.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::updateStatus
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
updateStatus.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::updateStatus
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
    const updateStatusForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::updateStatus
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
        updateStatusForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\HousekeepingController::storeMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
export const storeMaintenance = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMaintenance.url(options),
    method: 'post',
})

storeMaintenance.definition = {
    methods: ["post"],
    url: '/housekeeping/maintenance',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HousekeepingController::storeMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
storeMaintenance.url = (options?: RouteQueryOptions) => {
    return storeMaintenance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::storeMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
storeMaintenance.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMaintenance.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::storeMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
    const storeMaintenanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeMaintenance.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::storeMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
        storeMaintenanceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeMaintenance.url(options),
            method: 'post',
        })
    
    storeMaintenance.form = storeMaintenanceForm
/**
* @see \App\Http\Controllers\HousekeepingController::resolveMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
export const resolveMaintenance = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: resolveMaintenance.url(args, options),
    method: 'patch',
})

resolveMaintenance.definition = {
    methods: ["patch"],
    url: '/housekeeping/maintenance/{maintenance}/resolve',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\HousekeepingController::resolveMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
resolveMaintenance.url = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { maintenance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { maintenance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    maintenance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        maintenance: typeof args.maintenance === 'object'
                ? args.maintenance.id
                : args.maintenance,
                }

    return resolveMaintenance.definition.url
            .replace('{maintenance}', parsedArgs.maintenance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::resolveMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
resolveMaintenance.patch = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: resolveMaintenance.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::resolveMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
    const resolveMaintenanceForm = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resolveMaintenance.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::resolveMaintenance
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
        resolveMaintenanceForm.patch = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resolveMaintenance.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    resolveMaintenance.form = resolveMaintenanceForm
/**
* @see \App\Http\Controllers\HousekeepingController::storeLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
export const storeLostAndFound = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeLostAndFound.url(options),
    method: 'post',
})

storeLostAndFound.definition = {
    methods: ["post"],
    url: '/housekeeping/lost-and-found',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HousekeepingController::storeLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
storeLostAndFound.url = (options?: RouteQueryOptions) => {
    return storeLostAndFound.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::storeLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
storeLostAndFound.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeLostAndFound.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::storeLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
    const storeLostAndFoundForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeLostAndFound.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::storeLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
        storeLostAndFoundForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeLostAndFound.url(options),
            method: 'post',
        })
    
    storeLostAndFound.form = storeLostAndFoundForm
/**
* @see \App\Http\Controllers\HousekeepingController::updateLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
export const updateLostAndFound = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateLostAndFound.url(args, options),
    method: 'patch',
})

updateLostAndFound.definition = {
    methods: ["patch"],
    url: '/housekeeping/lost-and-found/{item}/claim',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\HousekeepingController::updateLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
updateLostAndFound.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return updateLostAndFound.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::updateLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
updateLostAndFound.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateLostAndFound.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::updateLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
    const updateLostAndFoundForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateLostAndFound.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::updateLostAndFound
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
        updateLostAndFoundForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateLostAndFound.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateLostAndFound.form = updateLostAndFoundForm
const HousekeepingController = { index, assign, updateStatus, storeMaintenance, resolveMaintenance, storeLostAndFound, updateLostAndFound }

export default HousekeepingController