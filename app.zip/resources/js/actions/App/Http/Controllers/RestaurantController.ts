import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/restaurant',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RestaurantController::storeOrder
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
export const storeOrder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeOrder.url(options),
    method: 'post',
})

storeOrder.definition = {
    methods: ["post"],
    url: '/restaurant/order',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RestaurantController::storeOrder
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
storeOrder.url = (options?: RouteQueryOptions) => {
    return storeOrder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::storeOrder
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
storeOrder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeOrder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RestaurantController::storeOrder
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
    const storeOrderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeOrder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::storeOrder
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
        storeOrderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeOrder.url(options),
            method: 'post',
        })
    
    storeOrder.form = storeOrderForm
/**
* @see \App\Http\Controllers\RestaurantController::settleOrder
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
export const settleOrder = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: settleOrder.url(args, options),
    method: 'post',
})

settleOrder.definition = {
    methods: ["post"],
    url: '/restaurant/orders/{order}/settle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RestaurantController::settleOrder
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
settleOrder.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { order: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: typeof args.order === 'object'
                ? args.order.id
                : args.order,
                }

    return settleOrder.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::settleOrder
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
settleOrder.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: settleOrder.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RestaurantController::settleOrder
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
    const settleOrderForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: settleOrder.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::settleOrder
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
        settleOrderForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: settleOrder.url(args, options),
            method: 'post',
        })
    
    settleOrder.form = settleOrderForm
/**
* @see \App\Http\Controllers\RestaurantController::storeProduct
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
export const storeProduct = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeProduct.url(options),
    method: 'post',
})

storeProduct.definition = {
    methods: ["post"],
    url: '/restaurant/products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RestaurantController::storeProduct
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
storeProduct.url = (options?: RouteQueryOptions) => {
    return storeProduct.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::storeProduct
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
storeProduct.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeProduct.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RestaurantController::storeProduct
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
    const storeProductForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeProduct.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::storeProduct
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
        storeProductForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeProduct.url(options),
            method: 'post',
        })
    
    storeProduct.form = storeProductForm
/**
* @see \App\Http\Controllers\RestaurantController::storeTable
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
export const storeTable = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTable.url(options),
    method: 'post',
})

storeTable.definition = {
    methods: ["post"],
    url: '/restaurant/tables',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RestaurantController::storeTable
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
storeTable.url = (options?: RouteQueryOptions) => {
    return storeTable.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::storeTable
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
storeTable.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTable.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RestaurantController::storeTable
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
    const storeTableForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeTable.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::storeTable
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
        storeTableForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeTable.url(options),
            method: 'post',
        })
    
    storeTable.form = storeTableForm
const RestaurantController = { index, storeOrder, settleOrder, storeProduct, storeTable }

export default RestaurantController