import PublicBookingController from './PublicBookingController'
import DashboardController from './DashboardController'
import FrontDeskController from './FrontDeskController'
import RoomController from './RoomController'
import ReservationController from './ReservationController'
import GuestController from './GuestController'
import InvoiceController from './InvoiceController'
import HousekeepingController from './HousekeepingController'
import HotelServiceController from './HotelServiceController'
import RestaurantController from './RestaurantController'
import InventoryController from './InventoryController'
import ExpenseController from './ExpenseController'
import CouponController from './CouponController'
import AuditLogController from './AuditLogController'
import NotificationController from './NotificationController'
import ReportController from './ReportController'
import Settings from './Settings'
import HotelController from './HotelController'
const Controllers = {
    PublicBookingController: Object.assign(PublicBookingController, PublicBookingController),
DashboardController: Object.assign(DashboardController, DashboardController),
FrontDeskController: Object.assign(FrontDeskController, FrontDeskController),
RoomController: Object.assign(RoomController, RoomController),
ReservationController: Object.assign(ReservationController, ReservationController),
GuestController: Object.assign(GuestController, GuestController),
InvoiceController: Object.assign(InvoiceController, InvoiceController),
HousekeepingController: Object.assign(HousekeepingController, HousekeepingController),
HotelServiceController: Object.assign(HotelServiceController, HotelServiceController),
RestaurantController: Object.assign(RestaurantController, RestaurantController),
InventoryController: Object.assign(InventoryController, InventoryController),
ExpenseController: Object.assign(ExpenseController, ExpenseController),
CouponController: Object.assign(CouponController, CouponController),
AuditLogController: Object.assign(AuditLogController, AuditLogController),
NotificationController: Object.assign(NotificationController, NotificationController),
ReportController: Object.assign(ReportController, ReportController),
Settings: Object.assign(Settings, Settings),
HotelController: Object.assign(HotelController, HotelController),
}

export default Controllers