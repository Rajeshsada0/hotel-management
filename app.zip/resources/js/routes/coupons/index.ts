import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CouponController::index
 * @see app/Http/Controllers/CouponController.php:23
 * @route '/coupons'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/coupons',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CouponController::index
 * @see app/Http/Controllers/CouponController.php:23
 * @route '/coupons'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CouponController::index
 * @see app/Http/Controllers/CouponController.php:23
 * @route '/coupons'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CouponController::index
 * @see app/Http/Controllers/CouponController.php:23
 * @route '/coupons'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CouponController::index
 * @see app/Http/Controllers/CouponController.php:23
 * @route '/coupons'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CouponController::index
 * @see app/Http/Controllers/CouponController.php:23
 * @route '/coupons'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CouponController::index
 * @see app/Http/Controllers/CouponController.php:23
 * @route '/coupons'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CouponController::store
 * @see app/Http/Controllers/CouponController.php:48
 * @route '/coupons'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/coupons',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CouponController::store
 * @see app/Http/Controllers/CouponController.php:48
 * @route '/coupons'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CouponController::store
 * @see app/Http/Controllers/CouponController.php:48
 * @route '/coupons'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CouponController::store
 * @see app/Http/Controllers/CouponController.php:48
 * @route '/coupons'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CouponController::store
 * @see app/Http/Controllers/CouponController.php:48
 * @route '/coupons'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CouponController::toggle
 * @see app/Http/Controllers/CouponController.php:78
 * @route '/coupons/{coupon}/toggle'
 */
export const toggle = (args: { coupon: number | { id: number } } | [coupon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggle.url(args, options),
    method: 'patch',
})

toggle.definition = {
    methods: ["patch"],
    url: '/coupons/{coupon}/toggle',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CouponController::toggle
 * @see app/Http/Controllers/CouponController.php:78
 * @route '/coupons/{coupon}/toggle'
 */
toggle.url = (args: { coupon: number | { id: number } } | [coupon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { coupon: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { coupon: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    coupon: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        coupon: typeof args.coupon === 'object'
                ? args.coupon.id
                : args.coupon,
                }

    return toggle.definition.url
            .replace('{coupon}', parsedArgs.coupon.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CouponController::toggle
 * @see app/Http/Controllers/CouponController.php:78
 * @route '/coupons/{coupon}/toggle'
 */
toggle.patch = (args: { coupon: number | { id: number } } | [coupon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggle.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CouponController::toggle
 * @see app/Http/Controllers/CouponController.php:78
 * @route '/coupons/{coupon}/toggle'
 */
    const toggleForm = (args: { coupon: number | { id: number } } | [coupon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggle.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CouponController::toggle
 * @see app/Http/Controllers/CouponController.php:78
 * @route '/coupons/{coupon}/toggle'
 */
        toggleForm.patch = (args: { coupon: number | { id: number } } | [coupon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggle.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggle.form = toggleForm
/**
* @see \App\Http\Controllers\CouponController::validate
 * @see app/Http/Controllers/CouponController.php:89
 * @route '/coupons/validate'
 */
export const validate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validate.url(options),
    method: 'post',
})

validate.definition = {
    methods: ["post"],
    url: '/coupons/validate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CouponController::validate
 * @see app/Http/Controllers/CouponController.php:89
 * @route '/coupons/validate'
 */
validate.url = (options?: RouteQueryOptions) => {
    return validate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CouponController::validate
 * @see app/Http/Controllers/CouponController.php:89
 * @route '/coupons/validate'
 */
validate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CouponController::validate
 * @see app/Http/Controllers/CouponController.php:89
 * @route '/coupons/validate'
 */
    const validateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: validate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CouponController::validate
 * @see app/Http/Controllers/CouponController.php:89
 * @route '/coupons/validate'
 */
        validateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: validate.url(options),
            method: 'post',
        })
    
    validate.form = validateForm
const coupons = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
toggle: Object.assign(toggle, toggle),
validate: Object.assign(validate, validate),
}

export default coupons