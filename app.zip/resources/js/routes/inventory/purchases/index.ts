import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\InventoryController::store
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/inventory/purchases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryController::store
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryController::store
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryController::store
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryController::store
 * @see app/Http/Controllers/InventoryController.php:157
 * @route '/inventory/purchases'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\InventoryController::receive
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
export const receive = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: receive.url(args, options),
    method: 'post',
})

receive.definition = {
    methods: ["post"],
    url: '/inventory/purchases/{purchase}/receive',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryController::receive
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
receive.url = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchase: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchase: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchase: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchase: typeof args.purchase === 'object'
                ? args.purchase.id
                : args.purchase,
                }

    return receive.definition.url
            .replace('{purchase}', parsedArgs.purchase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryController::receive
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
receive.post = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: receive.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryController::receive
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
    const receiveForm = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: receive.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryController::receive
 * @see app/Http/Controllers/InventoryController.php:213
 * @route '/inventory/purchases/{purchase}/receive'
 */
        receiveForm.post = (args: { purchase: number | { id: number } } | [purchase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: receive.url(args, options),
            method: 'post',
        })
    
    receive.form = receiveForm
const purchases = {
    store: Object.assign(store, store),
receive: Object.assign(receive, receive),
}

export default purchases