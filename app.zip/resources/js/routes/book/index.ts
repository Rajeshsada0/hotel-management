import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PublicBookingController::index
 * @see app/Http/Controllers/PublicBookingController.php:28
 * @route '/book'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/book',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicBookingController::index
 * @see app/Http/Controllers/PublicBookingController.php:28
 * @route '/book'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicBookingController::index
 * @see app/Http/Controllers/PublicBookingController.php:28
 * @route '/book'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicBookingController::index
 * @see app/Http/Controllers/PublicBookingController.php:28
 * @route '/book'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicBookingController::index
 * @see app/Http/Controllers/PublicBookingController.php:28
 * @route '/book'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicBookingController::index
 * @see app/Http/Controllers/PublicBookingController.php:28
 * @route '/book'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicBookingController::index
 * @see app/Http/Controllers/PublicBookingController.php:28
 * @route '/book'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PublicBookingController::availability
 * @see app/Http/Controllers/PublicBookingController.php:69
 * @route '/book/availability'
 */
export const availability = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})

availability.definition = {
    methods: ["get","head"],
    url: '/book/availability',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicBookingController::availability
 * @see app/Http/Controllers/PublicBookingController.php:69
 * @route '/book/availability'
 */
availability.url = (options?: RouteQueryOptions) => {
    return availability.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicBookingController::availability
 * @see app/Http/Controllers/PublicBookingController.php:69
 * @route '/book/availability'
 */
availability.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicBookingController::availability
 * @see app/Http/Controllers/PublicBookingController.php:69
 * @route '/book/availability'
 */
availability.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availability.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicBookingController::availability
 * @see app/Http/Controllers/PublicBookingController.php:69
 * @route '/book/availability'
 */
    const availabilityForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: availability.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicBookingController::availability
 * @see app/Http/Controllers/PublicBookingController.php:69
 * @route '/book/availability'
 */
        availabilityForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicBookingController::availability
 * @see app/Http/Controllers/PublicBookingController.php:69
 * @route '/book/availability'
 */
        availabilityForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    availability.form = availabilityForm
/**
* @see \App\Http\Controllers\PublicBookingController::coupon
 * @see app/Http/Controllers/PublicBookingController.php:122
 * @route '/book/coupon'
 */
export const coupon = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: coupon.url(options),
    method: 'post',
})

coupon.definition = {
    methods: ["post"],
    url: '/book/coupon',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PublicBookingController::coupon
 * @see app/Http/Controllers/PublicBookingController.php:122
 * @route '/book/coupon'
 */
coupon.url = (options?: RouteQueryOptions) => {
    return coupon.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicBookingController::coupon
 * @see app/Http/Controllers/PublicBookingController.php:122
 * @route '/book/coupon'
 */
coupon.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: coupon.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PublicBookingController::coupon
 * @see app/Http/Controllers/PublicBookingController.php:122
 * @route '/book/coupon'
 */
    const couponForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: coupon.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PublicBookingController::coupon
 * @see app/Http/Controllers/PublicBookingController.php:122
 * @route '/book/coupon'
 */
        couponForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: coupon.url(options),
            method: 'post',
        })
    
    coupon.form = couponForm
/**
* @see \App\Http\Controllers\PublicBookingController::reserve
 * @see app/Http/Controllers/PublicBookingController.php:142
 * @route '/book/reserve'
 */
export const reserve = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reserve.url(options),
    method: 'post',
})

reserve.definition = {
    methods: ["post"],
    url: '/book/reserve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PublicBookingController::reserve
 * @see app/Http/Controllers/PublicBookingController.php:142
 * @route '/book/reserve'
 */
reserve.url = (options?: RouteQueryOptions) => {
    return reserve.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicBookingController::reserve
 * @see app/Http/Controllers/PublicBookingController.php:142
 * @route '/book/reserve'
 */
reserve.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reserve.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PublicBookingController::reserve
 * @see app/Http/Controllers/PublicBookingController.php:142
 * @route '/book/reserve'
 */
    const reserveForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reserve.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PublicBookingController::reserve
 * @see app/Http/Controllers/PublicBookingController.php:142
 * @route '/book/reserve'
 */
        reserveForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reserve.url(options),
            method: 'post',
        })
    
    reserve.form = reserveForm
/**
* @see \App\Http\Controllers\PublicBookingController::confirmation
 * @see app/Http/Controllers/PublicBookingController.php:227
 * @route '/book/confirmation/{bookingNumber}'
 */
export const confirmation = (args: { bookingNumber: string | number } | [bookingNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirmation.url(args, options),
    method: 'get',
})

confirmation.definition = {
    methods: ["get","head"],
    url: '/book/confirmation/{bookingNumber}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicBookingController::confirmation
 * @see app/Http/Controllers/PublicBookingController.php:227
 * @route '/book/confirmation/{bookingNumber}'
 */
confirmation.url = (args: { bookingNumber: string | number } | [bookingNumber: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bookingNumber: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    bookingNumber: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        bookingNumber: args.bookingNumber,
                }

    return confirmation.definition.url
            .replace('{bookingNumber}', parsedArgs.bookingNumber.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicBookingController::confirmation
 * @see app/Http/Controllers/PublicBookingController.php:227
 * @route '/book/confirmation/{bookingNumber}'
 */
confirmation.get = (args: { bookingNumber: string | number } | [bookingNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirmation.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicBookingController::confirmation
 * @see app/Http/Controllers/PublicBookingController.php:227
 * @route '/book/confirmation/{bookingNumber}'
 */
confirmation.head = (args: { bookingNumber: string | number } | [bookingNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: confirmation.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicBookingController::confirmation
 * @see app/Http/Controllers/PublicBookingController.php:227
 * @route '/book/confirmation/{bookingNumber}'
 */
    const confirmationForm = (args: { bookingNumber: string | number } | [bookingNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: confirmation.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicBookingController::confirmation
 * @see app/Http/Controllers/PublicBookingController.php:227
 * @route '/book/confirmation/{bookingNumber}'
 */
        confirmationForm.get = (args: { bookingNumber: string | number } | [bookingNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: confirmation.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicBookingController::confirmation
 * @see app/Http/Controllers/PublicBookingController.php:227
 * @route '/book/confirmation/{bookingNumber}'
 */
        confirmationForm.head = (args: { bookingNumber: string | number } | [bookingNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: confirmation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    confirmation.form = confirmationForm
const book = {
    index: Object.assign(index, index),
availability: Object.assign(availability, availability),
coupon: Object.assign(coupon, coupon),
reserve: Object.assign(reserve, reserve),
confirmation: Object.assign(confirmation, confirmation),
}

export default book