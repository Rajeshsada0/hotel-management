import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/room-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RoomController::store
 * @see app/Http/Controllers/RoomController.php:112
 * @route '/room-types'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
export const update = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/room-types/{roomType}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
update.url = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { roomType: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { roomType: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    roomType: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        roomType: typeof args.roomType === 'object'
                ? args.roomType.id
                : args.roomType,
                }

    return update.definition.url
            .replace('{roomType}', parsedArgs.roomType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
update.put = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
    const updateForm = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RoomController::update
 * @see app/Http/Controllers/RoomController.php:146
 * @route '/room-types/{roomType}'
 */
        updateForm.put = (args: { roomType: number | { id: number } } | [roomType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const roomTypes = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
}

export default roomTypes