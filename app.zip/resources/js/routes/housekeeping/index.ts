import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import maintenance from './maintenance'
import lostAndFound from './lost-and-found'
/**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/housekeeping',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HousekeepingController::index
 * @see app/Http/Controllers/HousekeepingController.php:26
 * @route '/housekeeping'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
export const assign = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assign.url(options),
    method: 'post',
})

assign.definition = {
    methods: ["post"],
    url: '/housekeeping/assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
assign.url = (options?: RouteQueryOptions) => {
    return assign.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
assign.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assign.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
    const assignForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assign.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::assign
 * @see app/Http/Controllers/HousekeepingController.php:79
 * @route '/housekeeping/assign'
 */
        assignForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assign.url(options),
            method: 'post',
        })
    
    assign.form = assignForm
/**
* @see \App\Http\Controllers\HousekeepingController::status
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
export const status = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/housekeeping/tasks/{task}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\HousekeepingController::status
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
status.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return status.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::status
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
status.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::status
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
    const statusForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::status
 * @see app/Http/Controllers/HousekeepingController.php:104
 * @route '/housekeeping/tasks/{task}/status'
 */
        statusForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const housekeeping = {
    index: Object.assign(index, index),
assign: Object.assign(assign, assign),
status: Object.assign(status, status),
maintenance: Object.assign(maintenance, maintenance),
lostAndFound: Object.assign(lostAndFound, lostAndFound),
}

export default housekeeping