import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/housekeeping/lost-and-found',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:156
 * @route '/housekeeping/lost-and-found'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\HousekeepingController::claim
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
export const claim = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: claim.url(args, options),
    method: 'patch',
})

claim.definition = {
    methods: ["patch"],
    url: '/housekeeping/lost-and-found/{item}/claim',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\HousekeepingController::claim
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
claim.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return claim.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::claim
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
claim.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: claim.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::claim
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
    const claimForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: claim.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::claim
 * @see app/Http/Controllers/HousekeepingController.php:176
 * @route '/housekeeping/lost-and-found/{item}/claim'
 */
        claimForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: claim.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    claim.form = claimForm
const lostAndFound = {
    store: Object.assign(store, store),
claim: Object.assign(claim, claim),
}

export default lostAndFound