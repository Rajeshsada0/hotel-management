import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/housekeeping/maintenance',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::store
 * @see app/Http/Controllers/HousekeepingController.php:122
 * @route '/housekeeping/maintenance'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\HousekeepingController::resolve
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
export const resolve = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: resolve.url(args, options),
    method: 'patch',
})

resolve.definition = {
    methods: ["patch"],
    url: '/housekeeping/maintenance/{maintenance}/resolve',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\HousekeepingController::resolve
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
resolve.url = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { maintenance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { maintenance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    maintenance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        maintenance: typeof args.maintenance === 'object'
                ? args.maintenance.id
                : args.maintenance,
                }

    return resolve.definition.url
            .replace('{maintenance}', parsedArgs.maintenance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HousekeepingController::resolve
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
resolve.patch = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: resolve.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\HousekeepingController::resolve
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
    const resolveForm = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resolve.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HousekeepingController::resolve
 * @see app/Http/Controllers/HousekeepingController.php:142
 * @route '/housekeeping/maintenance/{maintenance}/resolve'
 */
        resolveForm.patch = (args: { maintenance: number | { id: number } } | [maintenance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resolve.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    resolve.form = resolveForm
const maintenance = {
    store: Object.assign(store, store),
resolve: Object.assign(resolve, resolve),
}

export default maintenance