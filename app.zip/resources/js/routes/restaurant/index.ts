import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import order from './order'
import products from './products'
import tables from './tables'
/**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/restaurant',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RestaurantController::index
 * @see app/Http/Controllers/RestaurantController.php:26
 * @route '/restaurant'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const restaurant = {
    index: Object.assign(index, index),
order: Object.assign(order, order),
products: Object.assign(products, products),
tables: Object.assign(tables, tables),
}

export default restaurant