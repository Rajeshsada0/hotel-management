import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/restaurant/order',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:58
 * @route '/restaurant/order'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RestaurantController::settle
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
export const settle = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: settle.url(args, options),
    method: 'post',
})

settle.definition = {
    methods: ["post"],
    url: '/restaurant/orders/{order}/settle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RestaurantController::settle
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
settle.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { order: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: typeof args.order === 'object'
                ? args.order.id
                : args.order,
                }

    return settle.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::settle
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
settle.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: settle.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RestaurantController::settle
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
    const settleForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: settle.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::settle
 * @see app/Http/Controllers/RestaurantController.php:93
 * @route '/restaurant/orders/{order}/settle'
 */
        settleForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: settle.url(args, options),
            method: 'post',
        })
    
    settle.form = settleForm
const order = {
    store: Object.assign(store, store),
settle: Object.assign(settle, settle),
}

export default order