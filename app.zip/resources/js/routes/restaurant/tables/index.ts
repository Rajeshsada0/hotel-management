import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/restaurant/tables',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:132
 * @route '/restaurant/tables'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const tables = {
    store: Object.assign(store, store),
}

export default tables