import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/restaurant/products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RestaurantController::store
 * @see app/Http/Controllers/RestaurantController.php:107
 * @route '/restaurant/products'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const products = {
    store: Object.assign(store, store),
}

export default products