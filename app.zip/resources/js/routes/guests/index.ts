import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\GuestController::index
 * @see app/Http/Controllers/GuestController.php:16
 * @route '/guests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/guests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GuestController::index
 * @see app/Http/Controllers/GuestController.php:16
 * @route '/guests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuestController::index
 * @see app/Http/Controllers/GuestController.php:16
 * @route '/guests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GuestController::index
 * @see app/Http/Controllers/GuestController.php:16
 * @route '/guests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\GuestController::index
 * @see app/Http/Controllers/GuestController.php:16
 * @route '/guests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\GuestController::index
 * @see app/Http/Controllers/GuestController.php:16
 * @route '/guests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\GuestController::index
 * @see app/Http/Controllers/GuestController.php:16
 * @route '/guests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\GuestController::store
 * @see app/Http/Controllers/GuestController.php:45
 * @route '/guests'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/guests',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GuestController::store
 * @see app/Http/Controllers/GuestController.php:45
 * @route '/guests'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuestController::store
 * @see app/Http/Controllers/GuestController.php:45
 * @route '/guests'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GuestController::store
 * @see app/Http/Controllers/GuestController.php:45
 * @route '/guests'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GuestController::store
 * @see app/Http/Controllers/GuestController.php:45
 * @route '/guests'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\GuestController::show
 * @see app/Http/Controllers/GuestController.php:70
 * @route '/guests/{guest}'
 */
export const show = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/guests/{guest}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GuestController::show
 * @see app/Http/Controllers/GuestController.php:70
 * @route '/guests/{guest}'
 */
show.url = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { guest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { guest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    guest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        guest: typeof args.guest === 'object'
                ? args.guest.id
                : args.guest,
                }

    return show.definition.url
            .replace('{guest}', parsedArgs.guest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuestController::show
 * @see app/Http/Controllers/GuestController.php:70
 * @route '/guests/{guest}'
 */
show.get = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GuestController::show
 * @see app/Http/Controllers/GuestController.php:70
 * @route '/guests/{guest}'
 */
show.head = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\GuestController::show
 * @see app/Http/Controllers/GuestController.php:70
 * @route '/guests/{guest}'
 */
    const showForm = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\GuestController::show
 * @see app/Http/Controllers/GuestController.php:70
 * @route '/guests/{guest}'
 */
        showForm.get = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\GuestController::show
 * @see app/Http/Controllers/GuestController.php:70
 * @route '/guests/{guest}'
 */
        showForm.head = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\GuestController::update
 * @see app/Http/Controllers/GuestController.php:86
 * @route '/guests/{guest}'
 */
export const update = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/guests/{guest}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\GuestController::update
 * @see app/Http/Controllers/GuestController.php:86
 * @route '/guests/{guest}'
 */
update.url = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { guest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { guest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    guest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        guest: typeof args.guest === 'object'
                ? args.guest.id
                : args.guest,
                }

    return update.definition.url
            .replace('{guest}', parsedArgs.guest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GuestController::update
 * @see app/Http/Controllers/GuestController.php:86
 * @route '/guests/{guest}'
 */
update.put = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\GuestController::update
 * @see app/Http/Controllers/GuestController.php:86
 * @route '/guests/{guest}'
 */
    const updateForm = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GuestController::update
 * @see app/Http/Controllers/GuestController.php:86
 * @route '/guests/{guest}'
 */
        updateForm.put = (args: { guest: number | { id: number } } | [guest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const guests = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
show: Object.assign(show, show),
update: Object.assign(update, update),
}

export default guests